namespace ReadME;

public partial class AjouterOuvrage : ContentPage
{
	public AjouterOuvrage()
	{
		InitializeComponent();
	}
}