//Auteur : jmy
//Date   : 24.04.2024
//Lieu   : ETML
//Descr. : squelette pour api avec blob

const express = require("express");
const Sequelize = require("sequelize");
const FS = require("fs");
const app = express();
const port = 3000;

const sequelize = new Sequelize("passionlecture", "root", "root", {
  host: "127.0.0.1",
  port: 6033,
  dialect: "mysql",
});

const Book = sequelize.define("Book", {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },

  title: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  epub: {
    type: Sequelize.BLOB("long"),
  },
});

//FROM DB
app.get("/epub/:id", function (req, res) {
  Book.findByPk(req.params.id).then((result) => {
    blob = result.epub;
    res
      .header("Content-Type", "application/epub+zip")
      .header(
        "Content-Disposition",
        'attachment; filename="' + result.title + '.epub"'
      )
      .header("Content-Length", blob.length)

      .send(blob);
  });
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
  sequelize.authenticate();
  Book.sync();

  const epubPath = `${__dirname}/books/Dumas, Alexandre - Les trois mousquetaires.epub`;
  const epubData = FS.readFileSync(epubPath);

  Book.findOrCreate({
    where: { id: 1 },
    defaults: {
      title: "mousquetaires",
      epub: epubData,
    },
  }).then(([book, created]) => {
    if (created) {
      console.log("Livre inséré en DB");
    } else {
      console.log("Livre déjà présent en DB");
    }
  });

  const epubPath1 = `${__dirname}/books/Dickens, Charles - A Christmas Carol.epub`;
  const epubData1 = FS.readFileSync(epubPath1);

  Book.findOrCreate({
    where: { id: 2 },
    defaults: {
      title: "A Christmas Carol",
      epub: epubData1,
    },
  }).then(([book, created]) => {
    if (created) {
      console.log("Livre inséré en DB");
    } else {
      console.log("Livre déjà présent en DB");
    }
  });

  const epubPath2 = `${__dirname}/books/Dickens, Charles - Oliver Twist.epub`;
  const epubData2 = FS.readFileSync(epubPath2);

  Book.findOrCreate({
    where: { id: 3 },
    defaults: {
      title: "Charles - Oliver Twist",
      epub: epubData2,
    },
  }).then(([book, created]) => {
    if (created) {
      console.log("Livre inséré en DB");
    } else {
      console.log("Livre déjà présent en DB");
    }
  });

  const epubPath3 = `${__dirname}/books/Doyle, Artur Conan - Sherlock Holmes.epub`;
  const epubData3 = FS.readFileSync(epubPath3);

  Book.findOrCreate({
    where: { id: 4 },
    defaults: {
      title: "Artur Conan - Sherlock Holmes",
      epub: epubData3,
    },
  }).then(([book, created]) => {
    if (created) {
      console.log("Livre inséré en DB");
    } else {
      console.log("Livre déjà présent en DB");
    }
  });

  const epubPath4 = `${__dirname}/books/La Fontaine, Jean de - Fables.epub`;
  const epubData4 = FS.readFileSync(epubPath4);

  Book.findOrCreate({
    where: { id: 5 },
    defaults: {
      title: "La Fontaine",
      epub: epubData4,
    },
  }).then(([book, created]) => {
    if (created) {
      console.log("Livre inséré en DB");
    } else {
      console.log("Livre déjà présent en DB");
    }
  });

  const epubPath5 = `${__dirname}/books/Verne, Jules - Le tour du monde en quatre-vingts jours.epub`;
  const epubData5 = FS.readFileSync(epubPath5);

  Book.findOrCreate({
    where: { id: 6 },
    defaults: {
      title: "Le tour du monde en quatre-vingts jours",
      epub: epubData5,
    },
  }).then(([book, created]) => {
    if (created) {
      console.log("Livre inséré en DB");
    } else {
      console.log("Livre déjà présent en DB");
    }
  });
});
